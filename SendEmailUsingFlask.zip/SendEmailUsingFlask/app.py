# importing libraries
from flask import Flask
from flask_mail import Mail,Message

app = Flask(__name__)
mail =  Mail(app) #inititalize mail class

# Configuration of mail
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'rockybhai0707@gmail.com'
app.config['MAIL_PASSWORD'] = 'rocky0707'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True

# app.config['MAIL_SERVER'] = 'smtp.gmail.com'
# app.config['MAIL_PORT'] = 465
# app.config['MAIL_USERNAME'] = 'rockybhai0707@gmail.com'
# app.config['MAIL_PASSWORD'] = 'rocky0707'
# app.config['MAIL_USE_TLS'] = True
# app.config['MAIL_USE_SSL'] = False

@app.route('/')
def index():

    msg = Message(
        'Hello',
        sender= 'rockybhai0707@gmail.com',
        recipients = ['jaimin.tailor123@gmail.com']
    )
    msg.body = 'Hello this mail from flask app'
    mail.send(msg)
    return 'Sent Mail'

@app.route('/sample')
def sample():
    return "Hello Billionaire"

if __name__ == "__main__":
    app.run(debug=True)